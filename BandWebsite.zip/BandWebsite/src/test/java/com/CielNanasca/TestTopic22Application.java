package com.CielNanasca;

import org.springframework.boot.SpringApplication;

import com.ShamrockRegiment.Topic33pplication;

public class TestTopic22Application {

	public static void main(String[] args) {
		SpringApplication.from(Topic33pplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
