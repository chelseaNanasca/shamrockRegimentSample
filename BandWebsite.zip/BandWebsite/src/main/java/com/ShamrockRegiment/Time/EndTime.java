package com.ShamrockRegiment.Time;

import com.ShamrockRegiment.models.eventModel;
import com.fasterxml.jackson.annotation.JsonBackReference;

public class EndTime extends Time {
	@JsonBackReference
	private eventModel event;
	//People have different EndTimes
	//For example: Colorguard may leave at a different time
	//So I should make an alternate EndTime 
	
	int endTimeHr = 0; 
	int endTimeMin = 0; 
	int endTimeSec =0;
	
	public EndTime() {}
	
	 public EndTime(int hr, int min, int sec) {
		super(hr, min,sec);
			this.endTimeHr = hr; 
			this.endTimeMin = min;
			this.endTimeSec = sec;
		 
			
		}
	
	 
}