package com.ShamrockRegiment.Time;

import com.ShamrockRegiment.models.eventModel;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonCreator;

public class CallTime extends Time {
	
	@JsonBackReference
	private eventModel event;
	int callTimeHr = 0; 
	int callTimeMin = 0;
	int callTimeSec =0; 
	
	public CallTime() {}
	
	@JsonCreator
	
	 public CallTime(int hr, int min, int sec) {
		 //extends the central time function 
		 //while also making it its own separate thing :)
		 
		 //People may have different Call Times 
		 //EX: Field Crew may be expected to come in earlier to paint
		 //People may also have multiple call times 
		
		 super(hr, min,sec);
		 
		
		 this.callTimeHr = hr; 
			this.callTimeMin= min;
			this.callTimeSec =sec; 
		
	
		 
		
		}
	 
}