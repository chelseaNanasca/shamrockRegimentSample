
package com.ShamrockRegiment.Time;

import com.ShamrockRegiment.models.eventModel;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonValue;

public class Time {

    @JsonManagedReference
    private eventModel event; 

    private int hr; 
    private int min;
    private int sec; 

    public Time() {
        this.hr = 0;
        this.min = 0;
        this.sec = 0;
    }
    
    public Time(int hr, int min, int sec) {
        this.hr = hr;
        this.min = min;
        this.sec = sec;
    }
    
    public Time(String timeString) {
        String[] parts = timeString.split(":");
        if (parts.length == 3) {
            this.hr = Integer.parseInt(parts[0]);
            this.min = Integer.parseInt(parts[1]);
            this.sec = Integer.parseInt(parts[2]);
        } else {
            throw new IllegalArgumentException("Invalid time format. Expected HH:mm:ss");
        }
    }
    
    @JsonValue
    @Override
    public String toString() {
        int displayHr = (hr % 12 == 0) ? 12 : hr % 12;
        String period = (hr >= 12) ? "PM" : "AM";
        return String.format("%02d:%02d:%02d %s", displayHr, min, sec, period);
    }
    
    public String to24HourFormat() {
        return String.format("%02d:%02d:%02d", hr, min, sec);
    }
    
    // Getters and setters
    public int getHours() {
        return hr;
    }

    public void setHours(int hr) {
        this.hr = hr;
    }

    public int getMinutes() {
        return min;
    }

    public void setMinutes(int min) {
        this.min = min;
    }

    public int getSeconds() {
        return sec;
    }

    public void setSeconds(int sec) {
        this.sec = sec;
    }
}

