package com.ShamrockRegiment.Time;

import com.ShamrockRegiment.models.eventModel;
import com.fasterxml.jackson.annotation.JsonBackReference;

public class PerformanceTime extends Time {
	//Everyone has the same performance time
	//But I think I might make a time for Front Ensemble to set up 
	
	@JsonBackReference
	private eventModel event;
	int performanceTimeHr = 0; 
	int performanceTimeMin = 0;
	int performanceTimeSec =0; 
	
	public PerformanceTime() {}
	
	 public PerformanceTime(int hr, int min, int sec) {
		
		 super(hr, min,sec);
			
			this.performanceTimeHr = hr; 
			this.performanceTimeMin = min;
			this.performanceTimeSec = sec; 
		
			
		}
	 
}