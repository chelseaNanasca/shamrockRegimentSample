package com.ShamrockRegiment.Time;

import com.ShamrockRegiment.models.eventModel;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public class Date {
    
    private eventModel event;
    
    private Integer month;
    private Integer day;
    private Integer year;
    
    public Date() {}
    
    @JsonCreator
    public Date(Integer month, Integer day, Integer year) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("Month must be between 1-12");
        }
        if (day < 1 || day > 31) {
            throw new IllegalArgumentException("Day must be between 1-31");
        }
        if (year < 1000 || year > 9999) {
            throw new IllegalArgumentException("Year must be four digits");
        }
        this.month = month;
        this.day = day;
        this.year = year;
    }

    @JsonValue
    @Override
    public String toString() {
        return String.format("%02d/%02d/%04d", month, day, year);
    }
    
    public static Date fromString(String dateStr) {
        // Ensure the string is not null or empty
        if (dateStr == null || dateStr.isEmpty()) {
            throw new IllegalArgumentException("Date string cannot be null or empty");
        }

        // Split the string by the "/" delimiter
        String[] parts = dateStr.split("/");

        // Ensure the string is in the correct format (MM/dd/yyyy)
        if (parts.length != 3) {
            throw new IllegalArgumentException("Date string must be in the format MM/dd/yyyy");
        }

        try {
            // Parse month, day, and year as integers
            Integer month = Integer.parseInt(parts[0]);
            Integer day = Integer.parseInt(parts[1]);
            Integer year = Integer.parseInt(parts[2]);

            // Return a new Date object
            return new Date(month, day, year);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number format in date string");
        }
    }

    // Getters and setters for month, day, and year
}
