package com.ShamrockRegiment;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.context.annotation.RequestScope;

import com.ShamrockRegiment.data.eventDataFunctionInterface;
import com.ShamrockRegiment.data.eventRepository;
import com.ShamrockRegiment.services.EventService;
import com.ShamrockRegiment.services.EventServiceInterface;

@Configuration
public class SpringConfig {
	@Bean(name="EventFunctions", initMethod ="init", destroyMethod="destroy")
	@Primary
	@RequestScope
	
	public EventServiceInterface getEventFunctions(eventDataFunctionInterface shamrockregiment) {
		return new EventService(shamrockregiment);
	}
	
	@Bean(name="shamrockregiment")
	@RequestScope
	
	public eventDataFunctionInterface getDataService() {
		return new eventRepository(); 
	}
	

}