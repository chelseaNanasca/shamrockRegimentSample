package com.ShamrockRegiment.models;


import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.ShamrockRegiment.Time.CallTime;
import com.ShamrockRegiment.Time.Date;
import com.ShamrockRegiment.Time.EndTime;
import com.ShamrockRegiment.Time.PerformanceTime;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId; 


public class eventsMapper implements RowMapper<eventModel> {


	@Override
	 public eventModel mapRow(ResultSet rs, int rowNum) throws SQLException {
		LocalDate eventDate = rs.getObject("eventDate", LocalDate.class);
		Date eventDateObject = new Date(eventDate.getMonthValue(), eventDate.getDayOfMonth(), eventDate.getYear());
		
		//Changing the CallTime to LocalTime because I made this 
		LocalTime performanceTime = rs.getObject("PerformanceTime", LocalTime.class);
		LocalTime callTime = rs.getObject("CallTime", LocalTime.class);
		LocalTime endTime = rs.getObject("EndTime", LocalTime.class);
		
		//Converting it to the CallTime Function
		 
		PerformanceTime performanceTimeObject = new PerformanceTime(performanceTime.getHour(), performanceTime.getMinute(), performanceTime.getSecond()); 
		CallTime callTimeObject = new CallTime(callTime.getHour(), callTime.getMinute(), callTime.getSecond());
		EndTime endTimeObject = new EndTime(endTime.getHour(), endTime.getMinute(), endTime.getSecond());
		
        // Create the eventModel object with these specific time objects
        eventModel event = new eventModel(
            rs.getLong("ID"),
            rs.getString("EventName"),
            rs.getString("EventLocation"),
            eventDateObject,
            performanceTimeObject,  
            callTimeObject,  
            endTimeObject  
        );
        	
        
        return event;
    }
}
   
	

