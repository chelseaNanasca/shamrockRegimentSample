
package com.ShamrockRegiment.models;

import com.ShamrockRegiment.Time.CallTime;
import com.ShamrockRegiment.Time.Date;
import com.ShamrockRegiment.Time.EndTime;
import com.ShamrockRegiment.Time.PerformanceTime;
import com.ShamrockRegiment.Time.Time;
import com.ShamrockRegiment.deserializer.dateDeserializer;
import com.ShamrockRegiment.deserializer.timeDeserializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class eventModel {

    private Long id = 0L;

    @JsonProperty("eventName")
    private String eventName = "";

    @JsonProperty("eventLocation")
    private String eventLocation = "";

    @JsonProperty("eventDate")
    @JsonDeserialize(using = dateDeserializer.class)
    private Date eventDate;

    @JsonProperty("performanceTime")
    @JsonDeserialize(using = timeDeserializer.class)
    private Time performanceTime;

    @JsonProperty("callTime")
    @JsonDeserialize(using = timeDeserializer.class)
    private Time callTime;

    @JsonProperty("endTime")
    @JsonDeserialize(using = timeDeserializer.class)
    private Time endTime;

    // No-argument constructor for Jackson
    public eventModel() {}

    // Parameterized constructor
    public eventModel(Long id, String eventName, String eventLocation, Date eventDate,
                      Time performanceTime, Time callTime, Time endTime) {
        this.id = id;
        this.eventName = eventName;
        this.eventLocation = eventLocation;
        this.eventDate = eventDate;
        this.performanceTime = performanceTime;
        this.callTime = callTime;
        this.endTime = endTime;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public void setEventLocation(String eventLocation) {
        this.eventLocation = eventLocation;
    }

    public Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    public Time getPerformanceTime() {
        return performanceTime;
    }

    public void setPerformanceTime(Time performanceTime) {
        this.performanceTime = performanceTime;
    }

    public Time getCallTime() {
        return callTime;
    }

    public void setCallTime(Time callTime) {
        this.callTime = callTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return "EventModel [id=" + id + ", eventName=" + eventName + ", eventLocation=" + eventLocation 
                + ", eventDate=" + eventDate + ", performanceTime=" + performanceTime 
                + ", callTime=" + callTime + ", endTime=" + endTime + "]";
    }
}

