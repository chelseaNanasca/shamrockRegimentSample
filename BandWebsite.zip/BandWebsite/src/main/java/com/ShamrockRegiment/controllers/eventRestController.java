package com.ShamrockRegiment.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ShamrockRegiment.data.eventDataFunctionInterface;
import com.ShamrockRegiment.data.eventRepository;
import com.ShamrockRegiment.models.eventModel;
import com.ShamrockRegiment.services.EventService;
import com.ShamrockRegiment.services.EventServiceInterface;
import com.fasterxml.jackson.annotation.JsonFormat;


@RestController 
@RequestMapping("/api/v1/event")


public class eventRestController {
	
	@Autowired 
	@Qualifier("EventFunctions")
	private final EventServiceInterface service; 
	public eventRestController(EventServiceInterface service) {
		this.service = service;
	}

	@GetMapping("/")
	public List<eventModel> displayEvents() {
		
	List<eventModel> events = service.getAllEvents();
		
		
		return events; 
		
	}
	
	@GetMapping("/search/{searchEvent}")
	
	public List<eventModel> searchEvent(@PathVariable(name = "searchEvent") String searchEvent) {
		
	
		List<eventModel> events = service.searchEvents(searchEvent); 
		return events; 
	
	}
	
	

	@PutMapping("/edit/{id}")

	public eventModel edit(@RequestBody eventModel model, @PathVariable(name="id") long id) {
		System.out.println("Received Edit Request for ID:" + id); 
		System.out.println("Updated Event Data:" + model.toString());
		return service.editEvent(id,model);
		}
	
	
	 
	
@PostMapping(value = "/create", consumes = "application/json")
public eventModel createEvent(@RequestBody eventModel newEvent) {
    System.out.println("Received POST request to create event: " + newEvent);
   
    return service.createEvent(newEvent);
		    

}
	 
@GetMapping("/{id}")

public eventModel getId(@PathVariable(name="id") long id) 
{
	return service.getEventbyId(id); 
}

	
@DeleteMapping("/remove/{id}")

public boolean removeEvent(@PathVariable(name="id") long id) {
	return service.deleteEvent(id); 
}
}
