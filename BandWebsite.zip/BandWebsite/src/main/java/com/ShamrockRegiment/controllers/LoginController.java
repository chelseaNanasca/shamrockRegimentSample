package com.ShamrockRegiment.controllers;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ShamrockRegiment.Time.Time;
import com.ShamrockRegiment.models.LoginModel;
import com.ShamrockRegiment.models.eventModel;
import com.ShamrockRegiment.services.EventService;
import com.ShamrockRegiment.services.EventServiceInterface;

import jakarta.validation.Valid;


@Controller
@RequestMapping("/login")


public class LoginController {
	
	private static final String VALID_USERNAME = "AdminUser";
	private static final String VALID_PASSWORD = "UserPassword";
	
	@Autowired
	private EventServiceInterface eventFunctions;

	@GetMapping("/")
	public String displayLoginForm(Model model) {
		model.addAttribute("loginModel", new LoginModel()); 
		return "loginForm.html"; 
	}
	
	@PostMapping("/processLogin")
	 public String processLogin(@Valid LoginModel loginModel, BindingResult bindingResult, Model model) {
	        if (bindingResult.hasErrors()) {
	            model.addAttribute("loginModel", loginModel);
	            return "loginForm.html";
	        }

	        if (!Objects.equals(VALID_USERNAME, loginModel.getUsername()) || 
	            !Objects.equals(VALID_PASSWORD, loginModel.getPassword())) {
	            
	            model.addAttribute("loginModel", loginModel);
	            model.addAttribute("errorMessage", "Invalid username or password.");
	            return "loginForm.html"; 
	        }

	        List<eventModel> events = eventFunctions.getAllEvents();
	        model.addAttribute("eventList", events);
	        return "loginResults.html";
	    }
	

	/*

	    @PostMapping("/createEvent")
	    public String addEvent(@ModelAttribute("eventModel") @Valid eventModel event, BindingResult bindingResult, Model model) {
	        if (bindingResult.hasErrors()) {
	            model.addAttribute("eventList", eventFunctions.getAllEvents());
	            return "loginResults.html";
	        }

	        System.out.println("Saving event: " + event.getEventName());
	        eventFunctions.createEvent(event);  // Save event to DB

	        return "redirect:/login/";
	        */
	        
	    }
	    




