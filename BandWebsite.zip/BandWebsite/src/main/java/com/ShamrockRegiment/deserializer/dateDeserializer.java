package com.ShamrockRegiment.deserializer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.ShamrockRegiment.Time.Date;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class dateDeserializer extends JsonDeserializer<Date> {
	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    @Override
    public Date deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        String dateStr = p.getText();
        LocalDate localDate = LocalDate.parse(dateStr, formatter);
        return new Date(localDate.getMonthValue(), localDate.getDayOfMonth(), localDate.getYear());
    }
}
