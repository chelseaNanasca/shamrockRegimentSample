package com.ShamrockRegiment.deserializer;

import java.io.IOException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import com.ShamrockRegiment.Time.Time;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class timeDeserializer extends JsonDeserializer<Time> {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    @Override
    public Time deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        String timeStr = p.getText();
        LocalTime localTime = LocalTime.parse(timeStr, formatter);
        return new Time(localTime.getHour(), localTime.getMinute(), localTime.getSecond());
    }
}