package com.ShamrockRegiment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic33pplication {

	public static void main(String[] args) {
		SpringApplication.run(Topic33pplication.class, args);
	}

}
