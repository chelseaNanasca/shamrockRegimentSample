package com.ShamrockRegiment.data;

import java.time.format.DateTimeFormatter;
import java.util.HashMap; 
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;

import com.ShamrockRegiment.Time.Date;
import com.ShamrockRegiment.Time.Time;
import com.ShamrockRegiment.models.eventModel;
import com.ShamrockRegiment.models.eventsMapper; 

@Repository
@Primary
public class eventRepository implements eventDataFunctionInterface{
	
	@Autowired
	DataSource dataSource; 
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public eventModel getId(long id) {
		List<eventModel> results = jdbcTemplate.query("SELECT * FROM `event` WHERE ID = ?", new eventsMapper(), id); 
		if(results.size()>0) {
		return results.get(0); 
		}
		else {
			return null; 
		}
		
	}
	
	

	@Override
	public List<eventModel> getEvent() {
		
		return jdbcTemplate.query("SELECT * FROM `event`", new eventsMapper()); 

	}

@Override
public List<eventModel> searchEvent(String searchEvent) {
    //Logging to make sure that the console is searching for the CORRECT term
    System.out.println("Search Results: " + searchEvent);

    //Replacing the placeholder null value with the searchEvent string
    String query = "SELECT * FROM `event` WHERE EventName LIKE ?";
    String finalQuery = query.replace("?", "'%" + searchEvent.trim() + "%'");
    System.out.println("Executing query: " + finalQuery);

    List<eventModel> results = jdbcTemplate.query(query, new eventsMapper(),
    		"%" + searchEvent.trim() + "%");
    
   
    return results;
}

	
	@Override
	public boolean removeEvent(long id) {
		int result = jdbcTemplate.update("DELETE FROM `event` WHERE ID = ?", id ); 
		
		if (result > 0) {
			return true; 
		}
		else {
			return false; 
		}
		
	}
	
	@Override
	public eventModel editEvent(long idToEdit, eventModel editEvent) {
	    System.out.println("Editing event with ID: " + idToEdit);
	    System.out.println("Updated event data: " + editEvent);

	    // Ensure consistent date format (yyyy-MM-dd)
	    String formattedEventDate = (editEvent.getEventDate() != null) ? 
	        editEvent.getEventDate().toString().replaceFirst("^(\\d{2})/(\\d{2})/(\\d{4})$", "$3-$1-$2") 
	        : null;

	    // Ensure times are in 24-hour format
	    String performanceTime = (editEvent.getPerformanceTime() != null) ? editEvent.getPerformanceTime().to24HourFormat() : null;
	    String callTime = (editEvent.getCallTime() != null) ? editEvent.getCallTime().to24HourFormat() : null;
	    String endTime = (editEvent.getEndTime() != null) ? editEvent.getEndTime().to24HourFormat() : null;

	    // Execute update query
	    int result = jdbcTemplate.update(
	        "UPDATE `event` SET EventName = ?, EventLocation = ?, EventDate = ?, PerformanceTime = ?, CallTime = ?, EndTime = ? WHERE ID = ?",
	        editEvent.getEventName(),
	        editEvent.getEventLocation(),
	        formattedEventDate,
	        performanceTime,
	        callTime,
	        endTime,
	        idToEdit
	    );

	    // Check if update was successful
	    if (result > 0) {
	        editEvent.setId(idToEdit);  // Ensure ID remains unchanged
	        System.out.println("Event successfully updated: " + editEvent);
	        return editEvent;
	    } else {
	        System.out.println("Failed to update event with ID: " + idToEdit);
	        return null;
	    }
	}

	
public eventModel createEvent(eventModel newEvent) {
    System.out.println("Service received event: " + newEvent);

String sql = "INSERT INTO event (EventName, EventLocation, EventDate, PerformanceTime, CallTime, EndTime) " +
         "VALUES (?, ?, ?, ?, ?, ?)";
   
    String formattedEventDate = (newEvent.getEventDate() != null) ? 
        newEvent.getEventDate().toString().replaceFirst("^(\\d{2})/(\\d{2})/(\\d{4})$", "$3-$1-$2") 
        : null;

    
String performanceTime = (newEvent.getPerformanceTime() != null) ? newEvent.getPerformanceTime().to24HourFormat() : null;
String callTime = (newEvent.getCallTime() != null) ? newEvent.getCallTime().to24HourFormat() : null;
String endTime = (newEvent.getEndTime() != null) ? newEvent.getEndTime().to24HourFormat() : null;

    
    int rowsAffected = jdbcTemplate.update(sql, 
        newEvent.getEventName(),
        newEvent.getEventLocation(),
        formattedEventDate,
        performanceTime,
        callTime,
        endTime
    );

  
    if (rowsAffected > 0) {
        System.out.println("Event successfully added: " + newEvent);
    return newEvent;
} else {
    System.out.println("Failed to insert event.");
        return null;
    }
}
	
}



	
	

