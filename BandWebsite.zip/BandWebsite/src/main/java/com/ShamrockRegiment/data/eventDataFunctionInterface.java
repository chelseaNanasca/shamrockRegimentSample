package com.ShamrockRegiment.data;

import java.util.List;

import com.ShamrockRegiment.models.eventModel;

public interface eventDataFunctionInterface {
	
	 

	public eventModel getId(long id); 
	public List<eventModel> getEvent(); 
	public List<eventModel> searchEvent(String searchEvent);
	
	public eventModel createEvent(eventModel newEvent); 
	public boolean removeEvent(long id); 
	
	public eventModel editEvent(long idToEdit, eventModel editEvent);
	
	
}
