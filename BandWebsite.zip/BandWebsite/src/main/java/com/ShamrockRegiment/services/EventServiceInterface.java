package com.ShamrockRegiment.services;

import java.util.List;

import com.ShamrockRegiment.models.eventModel;

public interface EventServiceInterface {

	
	//Lifestyle Methods
	public void test(); 
	public void init(); 
	public void destroy();
	
	//CRUD Operations
	
	public eventModel getEventbyId(long id); 
	public List<eventModel> getAllEvents(); 
	public List<eventModel> searchEvents(String searchEvent);
	
	public eventModel createEvent(eventModel newEvent); 
	public boolean deleteEvent(long id); 
	
	public eventModel editEvent(long idToEdit, eventModel editEvent);
	
	

}
