package com.ShamrockRegiment.services;

//import java.util.ArrayList;
//This is a list of functions that I used to add/remove events :3 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ShamrockRegiment.data.eventDataFunctionInterface;
import com.ShamrockRegiment.data.eventRepository;
import com.ShamrockRegiment.models.eventModel; 

@Service("EventService")

public class EventService implements EventServiceInterface {
	
	@Autowired 

 private eventDataFunctionInterface shamrockregiment;
	
	   public EventService(eventDataFunctionInterface shamrockregiment) {
	        this.shamrockregiment = shamrockregiment;
	    }
	


	//init, test, destroy
	@Override
	public void test() {
		System.out.println("EventFunctions are Working !"); 
		
	}

	@Override
	public void init() {
		System.out.println("Init method of the EventFunctions"); 
	}

	@Override
	public void destroy() {
		System.out.println("Destroy method of the EventFunctions"); 
		
	}

	@Override
	public eventModel getEventbyId(long id) {
		return shamrockregiment.getId(id);
		
	}

	@Override
	public List<eventModel> getAllEvents() {
		// TODO Auto-generated method stub
		List<eventModel> events = shamrockregiment.getEvent();
	    System.out.println("Fetched events: " + events);  // Add logging
	    return events;
		
		
	}

	@Override
	
	public List<eventModel> searchEvents(String searchEvent) {
		return shamrockregiment.searchEvent(searchEvent); 
		
	}
	
	@Override
	@Transactional
	public eventModel createEvent(eventModel newEvent) {
	    System.out.println("Service received event: " + newEvent);
	    
	    eventModel savedEvent = shamrockregiment.createEvent(newEvent);
	    
	    System.out.println("Event saved with ID: " + savedEvent.getId());
	    return savedEvent;  
	}


	@Override
	public boolean deleteEvent(long id) {
		return shamrockregiment.removeEvent(id);
	}

	@Override
	public eventModel editEvent(long idToEdit, eventModel editedEvent) {
		return shamrockregiment.editEvent(idToEdit, editedEvent);
	}



	
}
