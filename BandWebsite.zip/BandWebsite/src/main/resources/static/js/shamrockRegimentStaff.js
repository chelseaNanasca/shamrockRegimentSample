//Search Events
function openSearchEventModal() {
	   document.getElementById("searchEventModal").style.display = "block";  // Show the modal
	 	 }

function closeSearchEventModal() {
document.getElementById("searchEventModal").style.display = "none";  // Hide the modal
	   }	
		   
				   
   function searchEvent(event) {
       event.preventDefault(); // Prevent the form from submitting and refreshing the page

       const eventName = document.getElementById("eventName").value.trim();
       
       if (!eventName) {
           alert("Please enter an event name to search.");
           return;
       }

       fetch(`/api/v1/event/search/${encodeURIComponent(eventName)}`)
           .then(response => response.json())
           .then(events => {
               updateEventTable(events);  // Update the table with the new events
           })
           .catch(error => {
               console.error("Error searching events:", error);
           });
   }
   
	   
	   function updateSearchResultsTable(events) {
	       const tableBody = document.querySelector("table tbody");

	       // Clear existing table rows
	       tableBody.innerHTML = "";

	       if (events.length === 0) {
	           tableBody.innerHTML = `<tr><td colspan="7" class="text-center">No events found.</td></tr>`;
	           return;
	       }

	       // Populate table with search results
	       events.forEach(event => {
	           const row = `<tr>
	               <td>${event.id}</td>
	               <td>${event.eventName}</td>
	               <td>${event.eventLocation}</td>
	               <td>${formatDate(event.eventDate)}</td>
	               <td>${formatTime(event.performanceTime)}</td>
	               <td>${formatTime(event.callTime)}</td>
	               <td>${formatTime(event.endTime)}</td>
	           </tr>`;
	           tableBody.insertAdjacentHTML("beforeend", row);
	       });
	   }
	  
			function redirectToSearch(event) {
			event.preventDefault(); // Prevent default form submission
			const eventName = document.getElementById("eventName").value.trim();

			if (!eventName) {
		  alert("Please enter an event name to search.");
		  return;
		  }

		 		// Redirect to the correct API URL format
		       window.location.href = `/api/v1/event/search/${encodeURIComponent(eventName)}`;
		   }

		function updateEventTable(events) {
		    const tableBody = document.querySelector("table tbody");

		    // Clear existing table rows
		    tableBody.innerHTML = "";

		    if (events.length === 0) {
		        tableBody.innerHTML = `<tr><td colspan="7" class="text-center">No events available.</td></tr>`;
		        return;
		    }

					    // Populate table with new search results
		events.forEach(event => {
		    const row = `<tr>
		        <td>${event.id}</td>
		        <td>${event.eventName}</td>
		        <td>${event.eventLocation}</td>
		        <td>${event.eventDate}</td>
		        <td>${event.performanceTime}</td>
		        <td>${event.callTime}</td>
		        <td>${event.endTime}</td>
		    </tr>`;
		    tableBody.innerHTML += row;
		});
			}
			
//Add Event Functions ! 

	    function openAddEventModal() {
	       document.getElementById("addEventModal").style.display = "block";  // Show the modal
	   }

	   function closeAddEventModal() {
	       document.getElementById("addEventModal").style.display = "none";  // Hide the modal
	   }
	  
	   // Add new event
	   function formatDate(date) {
	       const parts = date.split("-");  // Split the date as YYYY-MM-DD
	       return parts[1] + "/" + parts[2] + "/" + parts[0];  // Reformat to MM/DD/YYYY
	   }
	   
	       function openIDInputModal() {
	       document.getElementById("editEventModal").style.display = "block";  // Show the modal
	   }

	   function closeIDInputModal() {
	       document.getElementById("editEventModal").style.display = "none";  // Hide the modal
	   }
	  

	   function submitEventForm(event) {
		alert("Form is being submitted"); 
	       event.preventDefault(); //prevents submission

	       // month/day/year formatting
	       const rawDate = document.getElementById("newEventDate").value;
	       const formattedDate = formatDate(rawDate);

	       const eventData = {
	           eventName: document.getElementById("newEventName").value,
	           eventLocation: document.getElementById("newEventLocation").value,
	           eventDate: formattedDate,
	           performanceTime: document.getElementById("newPerformanceTime").value,
	           callTime: document.getElementById("newCallTime").value,
	           endTime: document.getElementById("newEndTime").value
	       };
		   
	       fetch('/api/v1/event/create', {
	           method: 'POST',
	           headers: {
	               'Content-Type': 'application/json'
	           },
	           body: JSON.stringify(eventData)  
	      
		   
		    })
	       .then(response => response.json())
	       .then(data => {
			alert("Collected data" , eventData); 
	           closeAddEventModal();
	       })
	       .catch(error => {
	           console.error('Error adding event:', error);
	       });
		   }
		   
//Edit Event Function
let currentEventID = null; // Global variable to store the event ID

// --- Modal Functions ---
function openIDInputModal() {
    document.getElementById("editEventModal").style.display = "block";  // Show the modal
}

function closeIDInputModal() {
    document.getElementById("editEventModal").style.display = "none";  // Hide the modal
}

function convertMMDDYYYYtoYYYYMMDD(dateString) {
    const parts = dateString.split("/");
    if (parts.length === 3) {
        const [month, day, year] = parts;
        return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    return dateString;
}

function convertYYYYMMDDtoMMDDYYYY(dateString) {
    const parts = dateString.split("-");
    if (parts.length === 3) {
        const [year, month, day] = parts;
        return `${month}/${day}/${year}`;
    }
    return dateString;
}

// For time, ensure we have HH:MM:SS (if only HH:MM is provided, append :00)
function formatTimeWithSeconds(timeString) {
    const parts = timeString.split(":");
    if (parts.length === 2) {
        return `${parts[0]}:${parts[1]}:00`;
    } else if (parts.length >= 3) {
        return `${parts[0]}:${parts[1]}:${parts[2]}`;
    }
    return timeString;
}

// Format time for display in input fields (expects HH:MM:SS and returns HH:MM)
function formatTimeForInput(timeString) {
    const parts = timeString.split(":");
    if (parts.length >= 2) {
        return `${parts[0]}:${parts[1]}`;
    }
    return timeString;
}

function formatDateForInput(dateString) {
   
    const parts = dateString.split("/");
    if (parts.length === 3) {
        // Convert MM/DD/YYYY to YYYY-MM-DD
        const [month, day, year] = parts;
        return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    // Otherwise, assume it's already in the correct format
    return dateString;
}


function searchEventByID(event) {
    event.preventDefault(); // Prevent form submission

    const searchID = document.getElementById("eventID").value.trim();
    if (!searchID) {
        alert("Please enter an event ID.");
        return;
    }

    fetch(`/api/v1/event/${encodeURIComponent(searchID)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch event data.");
            }
            return response.json();
        })
        .then(eventData => {
            if (!eventData || !eventData.id) {
                alert("Event not found.");
                return;
            }

            // Global event stored
            currentEventID = eventData.id;
            console.log("Current Event ID Set:", currentEventID);

            document.getElementById("editEventName").value = eventData.eventName;
            document.getElementById("editEventLocation").value = eventData.eventLocation;
            
            document.getElementById("editEventDate").value = convertMMDDYYYYtoYYYYMMDD(eventData.eventDate);
            document.getElementById("editPerformanceTime").value = formatTimeForInput(eventData.performanceTime);
            document.getElementById("editCallTime").value = formatTimeForInput(eventData.callTime);
            document.getElementById("editEndTime").value = formatTimeForInput(eventData.endTime);

            // Show the event details section
            document.getElementById("eventDetails").style.display = "block";
        })
        .catch(error => {
            console.error("Error fetching event:", error);
            alert("An error occurred while retrieving the event.");
        });
}

// --- Submit Edited Event ---
function submitEditEventForm(event) {
    event.preventDefault(); 
    if (!currentEventID) {
        alert("Event ID is missing. Please search for an event first.");
        return;}
        
    const updatedEvent = {
        eventName: document.getElementById("editEventName").value.trim(),
        eventLocation: document.getElementById("editEventLocation").value.trim(),
        eventDate: convertYYYYMMDDtoMMDDYYYY(document.getElementById("editEventDate").value.trim()),
        performanceTime: formatTimeWithSeconds(document.getElementById("editPerformanceTime").value.trim()),
        callTime: formatTimeWithSeconds(document.getElementById("editCallTime").value.trim()),
        endTime: formatTimeWithSeconds(document.getElementById("editEndTime").value.trim())
    };

    console.log("Updated Event Data:", updatedEvent);

    fetch(`/api/v1/event/edit/${encodeURIComponent(currentEventID)}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(updatedEvent)
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`Error ${response.status}: ${text || "Failed to update event."}`);
            }); }
        return response.json().then(data => ({ status: response.status, data })); })
    .then(({ status, data }) => {
        console.log("Response Data:", data);  
        if (data && (data.success || status === 200)) {
            alert("Event updated successfully!");
            closeIDInputModal();
            window.location.reload()
           
        } else {
            throw new Error("Failed to update event: " + (data.message || "Unknown error."));  }})
    .catch(error => {
        console.error("Error occurred while updating the event:", error);
        alert("An error occurred while updating the event: " + error.message);
    });
}



// Open delete modal
function openDeleteModal() {
    const modal = document.getElementById("deleteEventModal");
    if (modal) {
        modal.style.display = "block";
    } else {
        console.error("Delete modal not found!");
    }
}

// Close delete modal
function closeDeleteModal() {
    document.getElementById("deleteEventModal").style.display = "none";
    document.getElementById("deleteEventDetails").style.display = "none"; // Hide event details section
}

// Function to search event by ID and display event details for deletion
function searchDeleteEventByID(event) {
    event.preventDefault(); // Prevent form submission

    const eventID = document.getElementById("deleteEventID").value.trim();
    if (!eventID) {
        alert("Please enter a valid event ID.");
        return;
    }

    // Fetch event details from the backend
    fetch(`/api/v1/event/${encodeURIComponent(eventID)}`)
        .then(response => response.json())
        .then(eventData => {
            if (!eventData || !eventData.id) {
                alert("Event not found.");
                return;
            }

            // Populate form fields with event data
            document.getElementById("deleteEventName").value = eventData.eventName;
            document.getElementById("deleteEventLocation").value = eventData.eventLocation;
            document.getElementById("deleteEventDate").value = formatDateForInput(eventData.eventDate);
            document.getElementById("deletePerformanceTime").value = formatTimeForInput(eventData.performanceTime);
            document.getElementById("deleteCallTime").value = formatTimeForInput(eventData.callTime);
            document.getElementById("deleteEndTime").value = formatTimeForInput(eventData.endTime);

            // Show the delete event details section
            document.getElementById("deleteEventDetails").style.display = "block";
        })
        .catch(error => {
            console.error("Error fetching event:", error);
            alert("An error occurred while retrieving the event.");
        });
}

// Function to confirm deletion and call backend API to delete event
function confirmDeleteEvent() {
    const eventId = document.getElementById("deleteEventID").value.trim();
    if (!eventId) {
        alert("Please enter a valid event ID.");
        return;
    }

    if (window.confirm("Are you sure you want to delete this event?")) {
        // Call the delete event function
        deleteEvent(eventId);
    }
}

// Function to delete event
async function deleteEvent(eventId) {
    try {
        const response = await fetch(`/api/v1/event/remove/${eventId}`, {
            method: 'DELETE' // Use DELETE method
        });

        if (response.ok) {
            alert("Event deleted successfully!");
            closeDeleteModal(); // Close modal after deletion
            // Optionally, you can refresh the page or update the UI here
        } else {
            const errorMessage = await response.text();
            alert(`Failed to delete event. Reason: ${errorMessage}`);
        }
    } catch (error) {
        console.error("Error deleting event:", error);
        alert("An error occurred while deleting the event.");
    }
}


 